﻿namespace ModbusHD
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.grpAddTag = new System.Windows.Forms.GroupBox();
            this.panelRadio = new System.Windows.Forms.Panel();
            this.btnAddUnit = new System.Windows.Forms.Button();
            this.rdbRtuMaster = new System.Windows.Forms.RadioButton();
            this.panelTCP = new System.Windows.Forms.Panel();
            this.txtIp = new System.Windows.Forms.TextBox();
            this.txtPort = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.panelRTU = new System.Windows.Forms.Panel();
            this.cboRtuParity = new System.Windows.Forms.ComboBox();
            this.label14 = new System.Windows.Forms.Label();
            this.cboRtuBaud = new System.Windows.Forms.ComboBox();
            this.label13 = new System.Windows.Forms.Label();
            this.cboRtuPort = new System.Windows.Forms.ComboBox();
            this.label12 = new System.Windows.Forms.Label();
            this.rdbRtuSlave = new System.Windows.Forms.RadioButton();
            this.rdbClient = new System.Windows.Forms.RadioButton();
            this.txtPollInterval = new System.Windows.Forms.TextBox();
            this.label18 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.rdbServer = new System.Windows.Forms.RadioButton();
            this.cboUnitID = new System.Windows.Forms.ComboBox();
            this.btnStart = new System.Windows.Forms.Button();
            this.btnConnect = new System.Windows.Forms.Button();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.dgCoils = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn8 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.cboTypeCoil = new System.Windows.Forms.ComboBox();
            this.label11 = new System.Windows.Forms.Label();
            this.txtStartCoil = new System.Windows.Forms.TextBox();
            this.txtLenCoil = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.dgDigitals = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.cboTypeDigital = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txtStartDigital = new System.Windows.Forms.TextBox();
            this.txtLenDigital = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.dgAnalogs = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.cboTypeAnalog = new System.Windows.Forms.ComboBox();
            this.label10 = new System.Windows.Forms.Label();
            this.txtStartAnalog = new System.Windows.Forms.TextBox();
            this.txtLenAnalog = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.grpChangeValue = new System.Windows.Forms.GroupBox();
            this.txtNewValue = new System.Windows.Forms.TextBox();
            this.btnCancelChangeValue = new System.Windows.Forms.Button();
            this.btnOkChangeValue = new System.Windows.Forms.Button();
            this.dgHoldings = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.cboTypeHolding = new System.Windows.Forms.ComboBox();
            this.txtStartHolding = new System.Windows.Forms.TextBox();
            this.txtLenHolding = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.timerPoll = new System.Windows.Forms.Timer(this.components);
            this.cmsWriteCoil = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.trueToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.falseToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cmsWriteDigital = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.TrueMenuDigital = new System.Windows.Forms.ToolStripMenuItem();
            this.FalseMenuDigital = new System.Windows.Forms.ToolStripMenuItem();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.txtStatus = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripStatusLabel1 = new System.Windows.Forms.ToolStripStatusLabel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.grpAddTag.SuspendLayout();
            this.panelRadio.SuspendLayout();
            this.panelTCP.SuspendLayout();
            this.panelRTU.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgCoils)).BeginInit();
            this.groupBox4.SuspendLayout();
            this.tabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgDigitals)).BeginInit();
            this.groupBox2.SuspendLayout();
            this.tabPage3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgAnalogs)).BeginInit();
            this.groupBox3.SuspendLayout();
            this.tabPage4.SuspendLayout();
            this.grpChangeValue.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgHoldings)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.cmsWriteCoil.SuspendLayout();
            this.cmsWriteDigital.SuspendLayout();
            this.statusStrip1.SuspendLayout();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // grpAddTag
            // 
            this.grpAddTag.Controls.Add(this.panelRadio);
            this.grpAddTag.Dock = System.Windows.Forms.DockStyle.Top;
            this.grpAddTag.Location = new System.Drawing.Point(0, 0);
            this.grpAddTag.Name = "grpAddTag";
            this.grpAddTag.Size = new System.Drawing.Size(404, 105);
            this.grpAddTag.TabIndex = 11;
            this.grpAddTag.TabStop = false;
            // 
            // panelRadio
            // 
            this.panelRadio.Controls.Add(this.cboUnitID);
            this.panelRadio.Controls.Add(this.btnAddUnit);
            this.panelRadio.Controls.Add(this.rdbRtuMaster);
            this.panelRadio.Controls.Add(this.panelTCP);
            this.panelRadio.Controls.Add(this.panelRTU);
            this.panelRadio.Controls.Add(this.rdbRtuSlave);
            this.panelRadio.Controls.Add(this.rdbClient);
            this.panelRadio.Controls.Add(this.txtPollInterval);
            this.panelRadio.Controls.Add(this.label18);
            this.panelRadio.Controls.Add(this.label16);
            this.panelRadio.Controls.Add(this.rdbServer);
            this.panelRadio.Location = new System.Drawing.Point(6, 12);
            this.panelRadio.Name = "panelRadio";
            this.panelRadio.Size = new System.Drawing.Size(385, 93);
            this.panelRadio.TabIndex = 13;
            // 
            // btnAddUnit
            // 
            this.btnAddUnit.Location = new System.Drawing.Point(123, 62);
            this.btnAddUnit.Name = "btnAddUnit";
            this.btnAddUnit.Size = new System.Drawing.Size(44, 22);
            this.btnAddUnit.TabIndex = 13;
            this.btnAddUnit.Text = "+";
            this.btnAddUnit.UseVisualStyleBackColor = true;
            this.btnAddUnit.Visible = false;
            // 
            // rdbRtuMaster
            // 
            this.rdbRtuMaster.AutoSize = true;
            this.rdbRtuMaster.Location = new System.Drawing.Point(270, 3);
            this.rdbRtuMaster.Name = "rdbRtuMaster";
            this.rdbRtuMaster.Size = new System.Drawing.Size(83, 17);
            this.rdbRtuMaster.TabIndex = 9;
            this.rdbRtuMaster.Text = "RTU Master";
            this.rdbRtuMaster.UseVisualStyleBackColor = true;
            this.rdbRtuMaster.CheckedChanged += new System.EventHandler(this.rdbRtuMaster_CheckedChanged);
            // 
            // panelTCP
            // 
            this.panelTCP.Controls.Add(this.txtIp);
            this.panelTCP.Controls.Add(this.txtPort);
            this.panelTCP.Controls.Add(this.label15);
            this.panelTCP.Controls.Add(this.label17);
            this.panelTCP.Location = new System.Drawing.Point(8, 24);
            this.panelTCP.Name = "panelTCP";
            this.panelTCP.Size = new System.Drawing.Size(264, 37);
            this.panelTCP.TabIndex = 11;
            // 
            // txtIp
            // 
            this.txtIp.Location = new System.Drawing.Point(33, 8);
            this.txtIp.Name = "txtIp";
            this.txtIp.Size = new System.Drawing.Size(97, 20);
            this.txtIp.TabIndex = 2;
            this.txtIp.Text = "127.0.0.1";
            // 
            // txtPort
            // 
            this.txtPort.Location = new System.Drawing.Point(171, 8);
            this.txtPort.Name = "txtPort";
            this.txtPort.Size = new System.Drawing.Size(72, 20);
            this.txtPort.TabIndex = 2;
            this.txtPort.Text = "502";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(7, 11);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(20, 13);
            this.label15.TabIndex = 7;
            this.label15.Text = "IP:";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(136, 11);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(29, 13);
            this.label17.TabIndex = 7;
            this.label17.Text = "Port:";
            // 
            // panelRTU
            // 
            this.panelRTU.Controls.Add(this.cboRtuParity);
            this.panelRTU.Controls.Add(this.label14);
            this.panelRTU.Controls.Add(this.cboRtuBaud);
            this.panelRTU.Controls.Add(this.label13);
            this.panelRTU.Controls.Add(this.cboRtuPort);
            this.panelRTU.Controls.Add(this.label12);
            this.panelRTU.Location = new System.Drawing.Point(7, 22);
            this.panelRTU.Name = "panelRTU";
            this.panelRTU.Size = new System.Drawing.Size(370, 39);
            this.panelRTU.TabIndex = 12;
            this.panelRTU.Visible = false;
            // 
            // cboRtuParity
            // 
            this.cboRtuParity.FormattingEnabled = true;
            this.cboRtuParity.Items.AddRange(new object[] {
            "None",
            "Even",
            "Odd",
            "Mark",
            "Space"});
            this.cboRtuParity.Location = new System.Drawing.Point(288, 10);
            this.cboRtuParity.Name = "cboRtuParity";
            this.cboRtuParity.Size = new System.Drawing.Size(68, 21);
            this.cboRtuParity.TabIndex = 8;
            this.cboRtuParity.Text = "None";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(250, 14);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(36, 13);
            this.label14.TabIndex = 7;
            this.label14.Text = "Parity:";
            // 
            // cboRtuBaud
            // 
            this.cboRtuBaud.FormattingEnabled = true;
            this.cboRtuBaud.Items.AddRange(new object[] {
            "9600",
            "19200",
            "115200"});
            this.cboRtuBaud.Location = new System.Drawing.Point(168, 10);
            this.cboRtuBaud.Name = "cboRtuBaud";
            this.cboRtuBaud.Size = new System.Drawing.Size(75, 21);
            this.cboRtuBaud.TabIndex = 8;
            this.cboRtuBaud.Text = "9600";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(113, 14);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(53, 13);
            this.label13.TabIndex = 7;
            this.label13.Text = "Baudrate:";
            // 
            // cboRtuPort
            // 
            this.cboRtuPort.FormattingEnabled = true;
            this.cboRtuPort.Location = new System.Drawing.Point(39, 10);
            this.cboRtuPort.Name = "cboRtuPort";
            this.cboRtuPort.Size = new System.Drawing.Size(64, 21);
            this.cboRtuPort.TabIndex = 8;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(7, 14);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(29, 13);
            this.label12.TabIndex = 7;
            this.label12.Text = "Port:";
            // 
            // rdbRtuSlave
            // 
            this.rdbRtuSlave.AutoSize = true;
            this.rdbRtuSlave.Location = new System.Drawing.Point(184, 3);
            this.rdbRtuSlave.Name = "rdbRtuSlave";
            this.rdbRtuSlave.Size = new System.Drawing.Size(78, 17);
            this.rdbRtuSlave.TabIndex = 10;
            this.rdbRtuSlave.Text = "RTU Slave";
            this.rdbRtuSlave.UseVisualStyleBackColor = true;
            this.rdbRtuSlave.CheckedChanged += new System.EventHandler(this.rdbRtuSlave_CheckedChanged);
            // 
            // rdbClient
            // 
            this.rdbClient.AutoSize = true;
            this.rdbClient.Checked = true;
            this.rdbClient.Location = new System.Drawing.Point(93, 3);
            this.rdbClient.Name = "rdbClient";
            this.rdbClient.Size = new System.Drawing.Size(75, 17);
            this.rdbClient.TabIndex = 8;
            this.rdbClient.TabStop = true;
            this.rdbClient.Text = "TCP Client";
            this.rdbClient.UseVisualStyleBackColor = true;
            this.rdbClient.CheckedChanged += new System.EventHandler(this.RdbClient_CheckedChanged);
            // 
            // txtPollInterval
            // 
            this.txtPollInterval.Location = new System.Drawing.Point(291, 63);
            this.txtPollInterval.Name = "txtPollInterval";
            this.txtPollInterval.Size = new System.Drawing.Size(72, 20);
            this.txtPollInterval.TabIndex = 2;
            this.txtPollInterval.Text = "1000";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(181, 66);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(103, 13);
            this.label18.TabIndex = 7;
            this.label18.Text = "Polling interval (ms) :";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(10, 66);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(43, 13);
            this.label16.TabIndex = 7;
            this.label16.Text = "Unit ID:";
            // 
            // rdbServer
            // 
            this.rdbServer.AutoSize = true;
            this.rdbServer.Location = new System.Drawing.Point(7, 3);
            this.rdbServer.Name = "rdbServer";
            this.rdbServer.Size = new System.Drawing.Size(80, 17);
            this.rdbServer.TabIndex = 8;
            this.rdbServer.Text = "TCP Server";
            this.rdbServer.UseVisualStyleBackColor = true;
            this.rdbServer.CheckedChanged += new System.EventHandler(this.RdbServer_CheckedChanged);
            // 
            // cboUnitID
            // 
            this.cboUnitID.FormattingEnabled = true;
            this.cboUnitID.Items.AddRange(new object[] {
            "1"});
            this.cboUnitID.Location = new System.Drawing.Point(51, 63);
            this.cboUnitID.Name = "cboUnitID";
            this.cboUnitID.Size = new System.Drawing.Size(66, 21);
            this.cboUnitID.TabIndex = 14;
            this.cboUnitID.Text = "1";
            // 
            // btnStart
            // 
            this.btnStart.BackColor = System.Drawing.Color.LightSlateGray;
            this.btnStart.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnStart.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnStart.ForeColor = System.Drawing.Color.White;
            this.btnStart.Location = new System.Drawing.Point(5, 5);
            this.btnStart.Name = "btnStart";
            this.btnStart.Size = new System.Drawing.Size(394, 44);
            this.btnStart.TabIndex = 4;
            this.btnStart.Text = "START";
            this.btnStart.UseVisualStyleBackColor = false;
            this.btnStart.Visible = false;
            this.btnStart.Click += new System.EventHandler(this.BtnStart_Click);
            // 
            // btnConnect
            // 
            this.btnConnect.BackColor = System.Drawing.Color.LightSlateGray;
            this.btnConnect.Dock = System.Windows.Forms.DockStyle.Fill;
            this.btnConnect.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnConnect.ForeColor = System.Drawing.Color.White;
            this.btnConnect.Location = new System.Drawing.Point(5, 5);
            this.btnConnect.Name = "btnConnect";
            this.btnConnect.Size = new System.Drawing.Size(394, 44);
            this.btnConnect.TabIndex = 4;
            this.btnConnect.Text = "Connect";
            this.btnConnect.UseVisualStyleBackColor = false;
            this.btnConnect.Click += new System.EventHandler(this.BtnConnect_Click);
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Controls.Add(this.tabPage4);
            this.tabControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl1.Enabled = false;
            this.tabControl1.Location = new System.Drawing.Point(0, 159);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(404, 338);
            this.tabControl1.TabIndex = 12;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.dgCoils);
            this.tabPage1.Controls.Add(this.groupBox4);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Size = new System.Drawing.Size(396, 312);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Coil Outputs";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // dgCoils
            // 
            this.dgCoils.AllowUserToAddRows = false;
            this.dgCoils.AllowUserToDeleteRows = false;
            this.dgCoils.AllowUserToResizeColumns = false;
            this.dgCoils.AllowUserToResizeRows = false;
            this.dgCoils.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dgCoils.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgCoils.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn7,
            this.dataGridViewTextBoxColumn8});
            this.dgCoils.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgCoils.Location = new System.Drawing.Point(0, 50);
            this.dgCoils.Name = "dgCoils";
            this.dgCoils.Size = new System.Drawing.Size(396, 262);
            this.dgCoils.TabIndex = 19;
            this.dgCoils.CellMouseDoubleClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.DgCoils_CellMouseDoubleClick);
            // 
            // dataGridViewTextBoxColumn7
            // 
            this.dataGridViewTextBoxColumn7.HeaderText = "Address";
            this.dataGridViewTextBoxColumn7.Name = "dataGridViewTextBoxColumn7";
            this.dataGridViewTextBoxColumn7.ReadOnly = true;
            this.dataGridViewTextBoxColumn7.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // dataGridViewTextBoxColumn8
            // 
            this.dataGridViewTextBoxColumn8.HeaderText = "Value";
            this.dataGridViewTextBoxColumn8.Name = "dataGridViewTextBoxColumn8";
            this.dataGridViewTextBoxColumn8.ReadOnly = true;
            this.dataGridViewTextBoxColumn8.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.cboTypeCoil);
            this.groupBox4.Controls.Add(this.label11);
            this.groupBox4.Controls.Add(this.txtStartCoil);
            this.groupBox4.Controls.Add(this.txtLenCoil);
            this.groupBox4.Controls.Add(this.label7);
            this.groupBox4.Controls.Add(this.label8);
            this.groupBox4.Dock = System.Windows.Forms.DockStyle.Top;
            this.groupBox4.Location = new System.Drawing.Point(0, 0);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(396, 50);
            this.groupBox4.TabIndex = 18;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Monitoring Data";
            // 
            // cboTypeCoil
            // 
            this.cboTypeCoil.FormattingEnabled = true;
            this.cboTypeCoil.Items.AddRange(new object[] {
            "Boolean",
            "Binary"});
            this.cboTypeCoil.Location = new System.Drawing.Point(279, 21);
            this.cboTypeCoil.Name = "cboTypeCoil";
            this.cboTypeCoil.Size = new System.Drawing.Size(86, 21);
            this.cboTypeCoil.TabIndex = 12;
            this.cboTypeCoil.Text = "Boolean";
            this.cboTypeCoil.SelectedIndexChanged += new System.EventHandler(this.RefreshDgCoil);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(239, 25);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(34, 13);
            this.label11.TabIndex = 11;
            this.label11.Text = "Type:";
            // 
            // txtStartCoil
            // 
            this.txtStartCoil.Location = new System.Drawing.Point(44, 21);
            this.txtStartCoil.Name = "txtStartCoil";
            this.txtStartCoil.Size = new System.Drawing.Size(64, 20);
            this.txtStartCoil.TabIndex = 2;
            this.txtStartCoil.Text = "1";
            this.txtStartCoil.TextChanged += new System.EventHandler(this.RefreshDgCoil);
            // 
            // txtLenCoil
            // 
            this.txtLenCoil.Location = new System.Drawing.Point(168, 21);
            this.txtLenCoil.Name = "txtLenCoil";
            this.txtLenCoil.Size = new System.Drawing.Size(64, 20);
            this.txtLenCoil.TabIndex = 2;
            this.txtLenCoil.Text = "10";
            this.txtLenCoil.TextChanged += new System.EventHandler(this.RefreshDgCoil);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(6, 25);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(32, 13);
            this.label7.TabIndex = 7;
            this.label7.Text = "Start:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(119, 25);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(43, 13);
            this.label8.TabIndex = 7;
            this.label8.Text = "Length:";
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.dgDigitals);
            this.tabPage2.Controls.Add(this.groupBox2);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Size = new System.Drawing.Size(396, 312);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Digital Inputs";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // dgDigitals
            // 
            this.dgDigitals.AllowUserToAddRows = false;
            this.dgDigitals.AllowUserToDeleteRows = false;
            this.dgDigitals.AllowUserToResizeColumns = false;
            this.dgDigitals.AllowUserToResizeRows = false;
            this.dgDigitals.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dgDigitals.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgDigitals.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn5,
            this.dataGridViewTextBoxColumn6});
            this.dgDigitals.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgDigitals.Location = new System.Drawing.Point(0, 50);
            this.dgDigitals.Name = "dgDigitals";
            this.dgDigitals.Size = new System.Drawing.Size(396, 262);
            this.dgDigitals.TabIndex = 19;
            this.dgDigitals.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.DgDigitals_CellDoubleClick);
            this.dgDigitals.CellMouseDoubleClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.DgDigitals_CellMouseDoubleClick);
            // 
            // dataGridViewTextBoxColumn5
            // 
            this.dataGridViewTextBoxColumn5.HeaderText = "Address";
            this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            this.dataGridViewTextBoxColumn5.ReadOnly = true;
            this.dataGridViewTextBoxColumn5.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // dataGridViewTextBoxColumn6
            // 
            this.dataGridViewTextBoxColumn6.HeaderText = "Value";
            this.dataGridViewTextBoxColumn6.Name = "dataGridViewTextBoxColumn6";
            this.dataGridViewTextBoxColumn6.ReadOnly = true;
            this.dataGridViewTextBoxColumn6.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.cboTypeDigital);
            this.groupBox2.Controls.Add(this.label3);
            this.groupBox2.Controls.Add(this.txtStartDigital);
            this.groupBox2.Controls.Add(this.txtLenDigital);
            this.groupBox2.Controls.Add(this.label4);
            this.groupBox2.Controls.Add(this.label19);
            this.groupBox2.Dock = System.Windows.Forms.DockStyle.Top;
            this.groupBox2.Location = new System.Drawing.Point(0, 0);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(396, 50);
            this.groupBox2.TabIndex = 20;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Monitoring Data";
            // 
            // cboTypeDigital
            // 
            this.cboTypeDigital.FormattingEnabled = true;
            this.cboTypeDigital.Items.AddRange(new object[] {
            "Boolean",
            "Binary"});
            this.cboTypeDigital.Location = new System.Drawing.Point(279, 21);
            this.cboTypeDigital.Name = "cboTypeDigital";
            this.cboTypeDigital.Size = new System.Drawing.Size(86, 21);
            this.cboTypeDigital.TabIndex = 12;
            this.cboTypeDigital.Text = "Boolean";
            this.cboTypeDigital.SelectedIndexChanged += new System.EventHandler(this.RefreshDgDigital);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(239, 25);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(34, 13);
            this.label3.TabIndex = 11;
            this.label3.Text = "Type:";
            // 
            // txtStartDigital
            // 
            this.txtStartDigital.Location = new System.Drawing.Point(44, 21);
            this.txtStartDigital.Name = "txtStartDigital";
            this.txtStartDigital.Size = new System.Drawing.Size(64, 20);
            this.txtStartDigital.TabIndex = 2;
            this.txtStartDigital.Text = "1";
            // 
            // txtLenDigital
            // 
            this.txtLenDigital.Location = new System.Drawing.Point(168, 21);
            this.txtLenDigital.Name = "txtLenDigital";
            this.txtLenDigital.Size = new System.Drawing.Size(64, 20);
            this.txtLenDigital.TabIndex = 2;
            this.txtLenDigital.Text = "10";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(6, 25);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(32, 13);
            this.label4.TabIndex = 7;
            this.label4.Text = "Start:";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(119, 25);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(43, 13);
            this.label19.TabIndex = 7;
            this.label19.Text = "Length:";
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.dgAnalogs);
            this.tabPage3.Controls.Add(this.groupBox3);
            this.tabPage3.Location = new System.Drawing.Point(4, 22);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Size = new System.Drawing.Size(396, 312);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "Analogue Inputs";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // dgAnalogs
            // 
            this.dgAnalogs.AllowUserToAddRows = false;
            this.dgAnalogs.AllowUserToDeleteRows = false;
            this.dgAnalogs.AllowUserToResizeColumns = false;
            this.dgAnalogs.AllowUserToResizeRows = false;
            this.dgAnalogs.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dgAnalogs.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgAnalogs.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn3,
            this.dataGridViewTextBoxColumn4});
            this.dgAnalogs.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgAnalogs.Location = new System.Drawing.Point(0, 50);
            this.dgAnalogs.Name = "dgAnalogs";
            this.dgAnalogs.Size = new System.Drawing.Size(396, 262);
            this.dgAnalogs.TabIndex = 17;
            this.dgAnalogs.CellValueChanged += new System.Windows.Forms.DataGridViewCellEventHandler(this.DgAnalogs_CellValueChanged);
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.HeaderText = "Address";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            this.dataGridViewTextBoxColumn3.ReadOnly = true;
            this.dataGridViewTextBoxColumn3.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.HeaderText = "Value";
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            this.dataGridViewTextBoxColumn4.ReadOnly = true;
            this.dataGridViewTextBoxColumn4.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn4.Width = 150;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.cboTypeAnalog);
            this.groupBox3.Controls.Add(this.label10);
            this.groupBox3.Controls.Add(this.txtStartAnalog);
            this.groupBox3.Controls.Add(this.txtLenAnalog);
            this.groupBox3.Controls.Add(this.label5);
            this.groupBox3.Controls.Add(this.label6);
            this.groupBox3.Dock = System.Windows.Forms.DockStyle.Top;
            this.groupBox3.Location = new System.Drawing.Point(0, 0);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(396, 50);
            this.groupBox3.TabIndex = 16;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Monitoring Data";
            // 
            // cboTypeAnalog
            // 
            this.cboTypeAnalog.FormattingEnabled = true;
            this.cboTypeAnalog.Items.AddRange(new object[] {
            "Binary",
            "Decimal",
            "Float",
            "Float Swap",
            "Double Float",
            "Double Float Swap"});
            this.cboTypeAnalog.Location = new System.Drawing.Point(254, 22);
            this.cboTypeAnalog.Name = "cboTypeAnalog";
            this.cboTypeAnalog.Size = new System.Drawing.Size(101, 21);
            this.cboTypeAnalog.TabIndex = 10;
            this.cboTypeAnalog.Text = "Decimal";
            this.cboTypeAnalog.SelectedIndexChanged += new System.EventHandler(this.RefreshDgAnalog);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(214, 25);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(34, 13);
            this.label10.TabIndex = 9;
            this.label10.Text = "Type:";
            // 
            // txtStartAnalog
            // 
            this.txtStartAnalog.Location = new System.Drawing.Point(44, 22);
            this.txtStartAnalog.Name = "txtStartAnalog";
            this.txtStartAnalog.Size = new System.Drawing.Size(64, 20);
            this.txtStartAnalog.TabIndex = 2;
            this.txtStartAnalog.Text = "1";
            this.txtStartAnalog.TextChanged += new System.EventHandler(this.RefreshDgAnalog);
            // 
            // txtLenAnalog
            // 
            this.txtLenAnalog.Location = new System.Drawing.Point(163, 22);
            this.txtLenAnalog.Name = "txtLenAnalog";
            this.txtLenAnalog.Size = new System.Drawing.Size(45, 20);
            this.txtLenAnalog.TabIndex = 2;
            this.txtLenAnalog.Text = "10";
            this.txtLenAnalog.TextChanged += new System.EventHandler(this.RefreshDgAnalog);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(6, 25);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(32, 13);
            this.label5.TabIndex = 7;
            this.label5.Text = "Start:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(114, 25);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(43, 13);
            this.label6.TabIndex = 7;
            this.label6.Text = "Length:";
            // 
            // tabPage4
            // 
            this.tabPage4.Controls.Add(this.grpChangeValue);
            this.tabPage4.Controls.Add(this.dgHoldings);
            this.tabPage4.Controls.Add(this.groupBox1);
            this.tabPage4.Location = new System.Drawing.Point(4, 22);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Size = new System.Drawing.Size(396, 312);
            this.tabPage4.TabIndex = 3;
            this.tabPage4.Text = "Holding Registers";
            this.tabPage4.UseVisualStyleBackColor = true;
            // 
            // grpChangeValue
            // 
            this.grpChangeValue.BackColor = System.Drawing.SystemColors.Info;
            this.grpChangeValue.Controls.Add(this.txtNewValue);
            this.grpChangeValue.Controls.Add(this.btnCancelChangeValue);
            this.grpChangeValue.Controls.Add(this.btnOkChangeValue);
            this.grpChangeValue.Location = new System.Drawing.Point(177, 85);
            this.grpChangeValue.Name = "grpChangeValue";
            this.grpChangeValue.Size = new System.Drawing.Size(210, 100);
            this.grpChangeValue.TabIndex = 20;
            this.grpChangeValue.TabStop = false;
            this.grpChangeValue.Text = "Write New Value";
            this.grpChangeValue.Visible = false;
            // 
            // txtNewValue
            // 
            this.txtNewValue.Location = new System.Drawing.Point(26, 29);
            this.txtNewValue.Name = "txtNewValue";
            this.txtNewValue.Size = new System.Drawing.Size(167, 20);
            this.txtNewValue.TabIndex = 2;
            this.txtNewValue.KeyDown += new System.Windows.Forms.KeyEventHandler(this.TxtNewValue_KeyDown);
            // 
            // btnCancelChangeValue
            // 
            this.btnCancelChangeValue.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnCancelChangeValue.Location = new System.Drawing.Point(124, 68);
            this.btnCancelChangeValue.Name = "btnCancelChangeValue";
            this.btnCancelChangeValue.Size = new System.Drawing.Size(69, 26);
            this.btnCancelChangeValue.TabIndex = 4;
            this.btnCancelChangeValue.Text = "Cancel";
            this.btnCancelChangeValue.UseVisualStyleBackColor = true;
            this.btnCancelChangeValue.Click += new System.EventHandler(this.BtnCancelChangeValue_Click);
            // 
            // btnOkChangeValue
            // 
            this.btnOkChangeValue.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnOkChangeValue.Location = new System.Drawing.Point(26, 68);
            this.btnOkChangeValue.Name = "btnOkChangeValue";
            this.btnOkChangeValue.Size = new System.Drawing.Size(92, 26);
            this.btnOkChangeValue.TabIndex = 4;
            this.btnOkChangeValue.Text = "OK";
            this.btnOkChangeValue.UseVisualStyleBackColor = true;
            this.btnOkChangeValue.Click += new System.EventHandler(this.BtnOkChangeValue_Click);
            // 
            // dgHoldings
            // 
            this.dgHoldings.AllowUserToAddRows = false;
            this.dgHoldings.AllowUserToDeleteRows = false;
            this.dgHoldings.AllowUserToResizeColumns = false;
            this.dgHoldings.AllowUserToResizeRows = false;
            this.dgHoldings.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dgHoldings.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgHoldings.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2});
            this.dgHoldings.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgHoldings.Location = new System.Drawing.Point(0, 50);
            this.dgHoldings.Name = "dgHoldings";
            this.dgHoldings.Size = new System.Drawing.Size(396, 262);
            this.dgHoldings.TabIndex = 19;
            this.dgHoldings.CellMouseDoubleClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.DgHoldings_CellMouseDoubleClick);
            this.dgHoldings.CellValueChanged += new System.Windows.Forms.DataGridViewCellEventHandler(this.DgHoldings_CellValueChanged);
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.HeaderText = "Address";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.ReadOnly = true;
            this.dataGridViewTextBoxColumn1.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.HeaderText = "Value";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            this.dataGridViewTextBoxColumn2.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn2.Width = 150;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.cboTypeHolding);
            this.groupBox1.Controls.Add(this.txtStartHolding);
            this.groupBox1.Controls.Add(this.txtLenHolding);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.label9);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Dock = System.Windows.Forms.DockStyle.Top;
            this.groupBox1.Location = new System.Drawing.Point(0, 0);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(396, 50);
            this.groupBox1.TabIndex = 18;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Monitoring Data";
            // 
            // cboTypeHolding
            // 
            this.cboTypeHolding.FormattingEnabled = true;
            this.cboTypeHolding.Items.AddRange(new object[] {
            "Binary",
            "Decimal",
            "Float",
            "Float Swap",
            "Double Float",
            "Double Float Swap"});
            this.cboTypeHolding.Location = new System.Drawing.Point(254, 22);
            this.cboTypeHolding.Name = "cboTypeHolding";
            this.cboTypeHolding.Size = new System.Drawing.Size(101, 21);
            this.cboTypeHolding.TabIndex = 8;
            this.cboTypeHolding.Text = "Decimal";
            this.cboTypeHolding.SelectedIndexChanged += new System.EventHandler(this.RefreshDgHolding);
            // 
            // txtStartHolding
            // 
            this.txtStartHolding.Location = new System.Drawing.Point(44, 22);
            this.txtStartHolding.Name = "txtStartHolding";
            this.txtStartHolding.Size = new System.Drawing.Size(64, 20);
            this.txtStartHolding.TabIndex = 2;
            this.txtStartHolding.Text = "1";
            this.txtStartHolding.TextChanged += new System.EventHandler(this.RefreshDgHolding);
            // 
            // txtLenHolding
            // 
            this.txtLenHolding.Location = new System.Drawing.Point(163, 22);
            this.txtLenHolding.Name = "txtLenHolding";
            this.txtLenHolding.Size = new System.Drawing.Size(45, 20);
            this.txtLenHolding.TabIndex = 2;
            this.txtLenHolding.Text = "10";
            this.txtLenHolding.TextChanged += new System.EventHandler(this.RefreshDgHolding);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(6, 25);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(32, 13);
            this.label1.TabIndex = 7;
            this.label1.Text = "Start:";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(214, 25);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(34, 13);
            this.label9.TabIndex = 7;
            this.label9.Text = "Type:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(114, 25);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(43, 13);
            this.label2.TabIndex = 7;
            this.label2.Text = "Length:";
            // 
            // timerPoll
            // 
            this.timerPoll.Interval = 1000;
            this.timerPoll.Tick += new System.EventHandler(this.TimerPoll_Tick);
            // 
            // cmsWriteCoil
            // 
            this.cmsWriteCoil.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.trueToolStripMenuItem,
            this.falseToolStripMenuItem});
            this.cmsWriteCoil.Name = "cmsWriteCoil";
            this.cmsWriteCoil.Size = new System.Drawing.Size(101, 48);
            this.cmsWriteCoil.Opening += new System.ComponentModel.CancelEventHandler(this.CmsWriteCoil_Opening);
            // 
            // trueToolStripMenuItem
            // 
            this.trueToolStripMenuItem.Name = "trueToolStripMenuItem";
            this.trueToolStripMenuItem.Size = new System.Drawing.Size(100, 22);
            this.trueToolStripMenuItem.Text = "True";
            this.trueToolStripMenuItem.Click += new System.EventHandler(this.TrueToolStripMenuItem_Click);
            // 
            // falseToolStripMenuItem
            // 
            this.falseToolStripMenuItem.Name = "falseToolStripMenuItem";
            this.falseToolStripMenuItem.Size = new System.Drawing.Size(100, 22);
            this.falseToolStripMenuItem.Text = "False";
            this.falseToolStripMenuItem.Click += new System.EventHandler(this.FalseToolStripMenuItem_Click);
            // 
            // cmsWriteDigital
            // 
            this.cmsWriteDigital.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.TrueMenuDigital,
            this.FalseMenuDigital});
            this.cmsWriteDigital.Name = "cmsWriteCoil";
            this.cmsWriteDigital.Size = new System.Drawing.Size(101, 48);
            this.cmsWriteDigital.Opening += new System.ComponentModel.CancelEventHandler(this.CmsWriteDigital_Opening);
            // 
            // TrueMenuDigital
            // 
            this.TrueMenuDigital.Name = "TrueMenuDigital";
            this.TrueMenuDigital.Size = new System.Drawing.Size(100, 22);
            this.TrueMenuDigital.Text = "True";
            this.TrueMenuDigital.Click += new System.EventHandler(this.TrueMenuDigital_Click);
            // 
            // FalseMenuDigital
            // 
            this.FalseMenuDigital.Name = "FalseMenuDigital";
            this.FalseMenuDigital.Size = new System.Drawing.Size(100, 22);
            this.FalseMenuDigital.Text = "False";
            this.FalseMenuDigital.Click += new System.EventHandler(this.FalseMenuDigital_Click);
            // 
            // statusStrip1
            // 
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.txtStatus,
            this.toolStripStatusLabel1});
            this.statusStrip1.Location = new System.Drawing.Point(0, 497);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(404, 22);
            this.statusStrip1.TabIndex = 13;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // txtStatus
            // 
            this.txtStatus.Name = "txtStatus";
            this.txtStatus.Size = new System.Drawing.Size(301, 17);
            this.txtStatus.Spring = true;
            // 
            // toolStripStatusLabel1
            // 
            this.toolStripStatusLabel1.ForeColor = System.Drawing.Color.CornflowerBlue;
            this.toolStripStatusLabel1.Name = "toolStripStatusLabel1";
            this.toolStripStatusLabel1.Size = new System.Drawing.Size(88, 17);
            this.toolStripStatusLabel1.Text = "hadiScada.com";
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.btnConnect);
            this.panel1.Controls.Add(this.btnStart);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 105);
            this.panel1.Name = "panel1";
            this.panel1.Padding = new System.Windows.Forms.Padding(5);
            this.panel1.Size = new System.Drawing.Size(404, 54);
            this.panel1.TabIndex = 15;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(404, 519);
            this.Controls.Add(this.tabControl1);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.statusStrip1);
            this.Controls.Add(this.grpAddTag);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Form1";
            this.Text = "ModbusHD by HadiSCADA";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.grpAddTag.ResumeLayout(false);
            this.panelRadio.ResumeLayout(false);
            this.panelRadio.PerformLayout();
            this.panelTCP.ResumeLayout(false);
            this.panelTCP.PerformLayout();
            this.panelRTU.ResumeLayout(false);
            this.panelRTU.PerformLayout();
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgCoils)).EndInit();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgDigitals)).EndInit();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.tabPage3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgAnalogs)).EndInit();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.tabPage4.ResumeLayout(false);
            this.grpChangeValue.ResumeLayout(false);
            this.grpChangeValue.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgHoldings)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.cmsWriteCoil.ResumeLayout(false);
            this.cmsWriteDigital.ResumeLayout(false);
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.GroupBox grpAddTag;
        private System.Windows.Forms.TextBox txtIp;
        private System.Windows.Forms.TextBox txtPort;
        private System.Windows.Forms.Button btnConnect;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.DataGridView dgAnalogs;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.TextBox txtStartAnalog;
        private System.Windows.Forms.TextBox txtLenAnalog;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.DataGridView dgHoldings;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox txtStartHolding;
        private System.Windows.Forms.TextBox txtLenHolding;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.DataGridView dgDigitals;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn6;
        private System.Windows.Forms.DataGridView dgCoils;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn7;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn8;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.TextBox txtStartCoil;
        private System.Windows.Forms.TextBox txtLenCoil;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Timer timerPoll;
        private System.Windows.Forms.ComboBox cboTypeHolding;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.ComboBox cboTypeAnalog;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.ContextMenuStrip cmsWriteCoil;
        private System.Windows.Forms.ToolStripMenuItem trueToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem falseToolStripMenuItem;
        private System.Windows.Forms.GroupBox grpChangeValue;
        private System.Windows.Forms.TextBox txtNewValue;
        private System.Windows.Forms.Button btnCancelChangeValue;
        private System.Windows.Forms.Button btnOkChangeValue;
        private System.Windows.Forms.RadioButton rdbClient;
        private System.Windows.Forms.RadioButton rdbServer;
        private System.Windows.Forms.Button btnStart;
        private System.Windows.Forms.ContextMenuStrip cmsWriteDigital;
        private System.Windows.Forms.ToolStripMenuItem TrueMenuDigital;
        private System.Windows.Forms.ToolStripMenuItem FalseMenuDigital;
        private System.Windows.Forms.Panel panelTCP;
        private System.Windows.Forms.RadioButton rdbRtuMaster;
        private System.Windows.Forms.RadioButton rdbRtuSlave;
        private System.Windows.Forms.Panel panelRTU;
        private System.Windows.Forms.ComboBox cboRtuParity;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.ComboBox cboRtuBaud;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.ComboBox cboRtuPort;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel1;
        private System.Windows.Forms.ToolStripStatusLabel txtStatus;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Panel panelRadio;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.TextBox txtPollInterval;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.ComboBox cboTypeCoil;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.ComboBox cboTypeDigital;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtStartDigital;
        private System.Windows.Forms.TextBox txtLenDigital;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.ComboBox cboUnitID;
        private System.Windows.Forms.Button btnAddUnit;
    }
}

