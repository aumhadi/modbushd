﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO.Ports;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using EasyModbus;

namespace ModbusHD
{
    public partial class Form1 : Form
    {

        ModbusClient ModClient;
        ModbusServer ModServer;
        public bool[] CoilOutputs { get; set; }
        public bool[] DigitalInputs { get; set; }
        public short[] AnalogInputs { get; set; }
        public short[] HoldingRegisters { get; set; }
        public List<int> UnitIDs { get; set; }

        List<ModbusServer> ModbusServers = new List<ModbusServer>();

        public Form1()
        {
            InitializeComponent();

            CoilOutputs = new bool[65535];
            DigitalInputs = new bool[65535];
            AnalogInputs = new short[65535];
            HoldingRegisters = new short[65535];

            UnitIDs = new List<int>();
            UnitIDs.Add(1);

        }

        private void BtnConnect_Click(object sender, EventArgs e)
        {
            txtStatus.Text = "";
            try
            {
                if (btnConnect.Text.Equals("Connect"))
                {
                    dgCoils.Rows.Clear();
                    dgDigitals.Rows.Clear();
                    dgAnalogs.Rows.Clear();
                    dgHoldings.Rows.Clear();
                    if (rdbClient.Checked)
                    {
                        ModClient = new ModbusClient(txtIp.Text, int.Parse(txtPort.Text));
                    }
                    else if (rdbRtuMaster.Checked)
                    {
                        ModClient = new ModbusClient(cboRtuPort.Text);
                        ModClient.Baudrate = int.Parse(cboRtuBaud.Text);
                        switch (cboRtuParity.Text)
                        {
                            case "None":
                                ModClient.Parity = Parity.None;
                                break;
                            case "Even":
                                ModClient.Parity = Parity.Even;
                                break;
                            case "Odd":
                                ModClient.Parity = Parity.Odd;
                                break;
                            case "Space":
                                ModClient.Parity = Parity.Space;
                                break;
                            case "Mark":
                                ModClient.Parity = Parity.Mark;
                                break;
                        }
                    }
                    ModClient.UnitIdentifier = byte.Parse(cboUnitID.Text);
                    ModClient.Connect();
                    timerPoll.Interval = int.Parse(txtPollInterval.Text);
                    timerPoll.Start();
                    btnConnect.Text = "Disconnect";
                    panelTCP.Enabled = false;
                    panelRTU.Enabled = false;
                    panelRadio.Enabled = false;
                    tabControl1.Enabled = true;
                }
                else if (btnConnect.Text.Equals("Disconnect"))
                {
                    timerPoll.Stop();
                    ModClient.Disconnect();
                    ModClient = null;
                    btnConnect.Text = "Connect";
                    panelTCP.Enabled = true;
                    panelRTU.Enabled = true;
                    panelRadio.Enabled = true;
                    tabControl1.Enabled = false;
                }
            }
            catch (Exception ex)
            {
                txtStatus.Text = "Error: " + ex.Message;
            }
        }

        private void TimerPoll_Tick(object sender, EventArgs e)
        {
            timerPoll.Stop();
            string sTab = tabControl1.SelectedTab.Text;
            if (sTab.Equals("Holding Registers"))
            {
                int iStart = int.Parse(txtStartHolding.Text);
                try
                {
                    int iLen = int.Parse(txtLenHolding.Text);
                    int[] Values = ModClient.ReadHoldingRegisters(iStart - 1, iLen);
                    for (int i = 0; i < Values.Length; i++)
                    {
                        HoldingRegisters[iStart + i] = (short)Values[i];
                    }
                    if (cboTypeHolding.Text.Equals("Decimal"))
                    {
                        if (dgHoldings.Rows.Count != iLen)
                        {
                            dgHoldings.Rows.Clear();
                            for (int i = 0; i < iLen; i++)
                            {
                                dgHoldings.Rows.Add(iStart + i + 40000, HoldingRegisters[iStart + i]);
                            }
                        } else
                        {
                            for (int i = 0; i < iLen; i++)
                            {
                                dgHoldings.Rows[i].Cells[0].Value = iStart + i + 40000;
                                dgHoldings.Rows[i].Cells[1].Value = HoldingRegisters[iStart + i];
                            }
                        }
                        
                    }
                    else if (cboTypeHolding.Text.Equals("Float") || cboTypeHolding.Text.Equals("Float Swap"))
                    {
                        List<double> lstData = new List<double>();
                        for (int i = 0; i < iLen; i++)
                        {
                            short int1 = (short)HoldingRegisters[iStart + i];
                            short int2 = (short)HoldingRegisters[iStart + i + 1];
                            //byte[] intBytes1 = BitConverter.GetBytes(int1);
                            //if (BitConverter.IsLittleEndian) Array.Reverse(intBytes1);
                            //byte[] result1 = intBytes1;
                            //byte[] intBytes2 = BitConverter.GetBytes(int2);
                            //if (BitConverter.IsLittleEndian) Array.Reverse(intBytes2);
                            //byte[] result2 = intBytes2;
                            //byte[] _bytes = new byte[4];
                            //if (cboTypeHolding.Text.Equals("Float")){
                            //    _bytes[0] = intBytes2[1];
                            //    _bytes[1] = intBytes2[0];
                            //    _bytes[2] = intBytes1[1];
                            //    _bytes[3] = intBytes1[0];
                            //}
                            //else if (cboTypeHolding.Text.Equals("Float Swap"))
                            //{
                            //    _bytes[2] = intBytes2[1];
                            //    _bytes[3] = intBytes2[0];
                            //    _bytes[1] = intBytes1[1];
                            //    _bytes[0] = intBytes1[0];
                            //}
                            //double _val = BitConverter.ToSingle(_bytes, 0);
                            double _val = 0;
                            if (cboTypeHolding.Text.Equals("Float")) _val = CovertDW2Double(int1, int2);
                            if (cboTypeHolding.Text.Equals("Float Swap")) _val = CovertDW2DoubleSwap(int1, int2);
                            _val = Math.Round(_val, 3);
                            lstData.Add(_val);
                            i += 1;
                        }
                        if (dgHoldings.Rows.Count != lstData.Count)
                        {
                            dgHoldings.Rows.Clear();
                            int idr = iStart;
                            for (int i = 0; i < lstData.Count; i++)
                            {
                                dgHoldings.Rows.Add(idr + 40000, lstData[i]);
                                idr += 2;
                            }
                        }
                        else
                        {
                            int idr = iStart;
                            for (int i = 0; i < lstData.Count; i++)
                            {
                                dgHoldings.Rows[i].Cells[0].Value = idr + 40000;
                                dgHoldings.Rows[i].Cells[1].Value = lstData[i];
                                idr += 2;
                            }
                        }                        
                    }
                    else if (cboTypeHolding.Text.Equals("Binary"))
                    {
                        if (dgHoldings.Rows.Count != iLen)
                        {
                            dgHoldings.Rows.Clear();
                            for (int i = 0; i < iLen; i++)
                            {
                                dgHoldings.Rows.Add(iStart + i + 40000, Convert.ToString(HoldingRegisters[iStart + i],2).PadLeft(16, '0'));
                            }
                        }
                        else
                        {
                            for (int i = 0; i < iLen; i++)
                            {
                                dgHoldings.Rows[i].Cells[0].Value = iStart + i + 40000;
                                dgHoldings.Rows[i].Cells[1].Value = Convert.ToString(HoldingRegisters[iStart + i], 2).PadLeft(16, '0');
                            }
                        }
                    }
                    else if (cboTypeHolding.Text.Equals("Double Float") || cboTypeHolding.Text.Equals("Double Float Swap"))
                    {
                        List<double> lstData = new List<double>();
                        for (int i = 0; i < iLen; i++)
                        {
                            short int1 = (short)HoldingRegisters[iStart + i];
                            short int2 = (short)HoldingRegisters[iStart + i + 1];
                            short int3 = (short)HoldingRegisters[iStart + i + 2];
                            short int4 = (short)HoldingRegisters[iStart + i + 3];
                            double _val = 0;
                            if (cboTypeHolding.Text.Equals("Double Float")) _val = CovertQW2Double(int1, int2, int3, int4);
                            if (cboTypeHolding.Text.Equals("Double Float Swap")) _val = CovertQW2DoubleSwap(int1, int2, int3, int4);
                            _val = Math.Round(_val, 3);
                            lstData.Add(_val);
                            i += 3;
                        }
                        if (dgHoldings.Rows.Count != lstData.Count)
                        {
                            dgHoldings.Rows.Clear();
                            int idr = iStart;
                            for (int i = 0; i < lstData.Count; i++)
                            {
                                dgHoldings.Rows.Add(idr + 40000, lstData[i]);
                                idr += 4;
                            }
                        }
                        else
                        {
                            int idr = iStart;
                            for (int i = 0; i < lstData.Count; i++)
                            {
                                dgHoldings.Rows[i].Cells[0].Value = idr + 40000;
                                dgHoldings.Rows[i].Cells[1].Value = lstData[i];
                                idr += 4;
                            }
                        }
                    }                    
                }
                catch (Exception ex)
                {
                    ex.ToString();
                }
            }
            else if (sTab.Equals("Analogue Inputs"))
            {
                int iStart = int.Parse(txtStartAnalog.Text);                
                try
                {
                    int iLen = int.Parse(txtLenAnalog.Text);
                    int[] Values = ModClient.ReadInputRegisters(iStart - 1, iLen);
                    for (int i = 0; i < Values.Length; i++)
                    {
                        AnalogInputs[iStart + i] = (short)Values[i];
                    }
                    if (cboTypeAnalog.Text.Equals("Decimal"))
                    {
                        if (dgAnalogs.Rows.Count != iLen)
                        {
                            dgAnalogs.Rows.Clear();
                            for (int i = 0; i < iLen; i++)
                            {
                                dgAnalogs.Rows.Add(iStart + i + 30000, AnalogInputs[iStart + i]);
                            }
                        }
                        else
                        {
                            for (int i = 0; i < iLen; i++)
                            {
                                dgAnalogs.Rows[i].Cells[0].Value = iStart + i + 30000;
                                dgAnalogs.Rows[i].Cells[1].Value = AnalogInputs[iStart + i];
                            }
                        }

                    }
                    else if (cboTypeAnalog.Text.Equals("Float") || cboTypeAnalog.Text.Equals("Float Swap"))
                    {
                        List<double> lstData = new List<double>();
                        for (int i = 0; i < iLen; i++)
                        {
                            short int1 = (short)AnalogInputs[iStart + i];
                            short int2 = (short)AnalogInputs[iStart + i + 1];
                            //byte[] intBytes1 = BitConverter.GetBytes(int1);
                            //if (BitConverter.IsLittleEndian) Array.Reverse(intBytes1);
                            //byte[] result1 = intBytes1;
                            //byte[] intBytes2 = BitConverter.GetBytes(int2);
                            //if (BitConverter.IsLittleEndian) Array.Reverse(intBytes2);
                            //byte[] result2 = intBytes2;
                            //byte[] _bytes = new byte[4];
                            //if (cboTypeAnalog.Text.Equals("Float"))
                            //{
                            //    _bytes[0] = intBytes2[1];
                            //    _bytes[1] = intBytes2[0];
                            //    _bytes[2] = intBytes1[1];
                            //    _bytes[3] = intBytes1[0];
                            //}
                            //else if (cboTypeAnalog.Text.Equals("Float Swap"))
                            //{
                            //    _bytes[2] = intBytes2[1];
                            //    _bytes[3] = intBytes2[0];
                            //    _bytes[1] = intBytes1[1];
                            //    _bytes[0] = intBytes1[0];
                            //}
                            //double _val = BitConverter.ToSingle(_bytes, 0);
                            double _val = 0;
                            if (cboTypeAnalog.Text.Equals("Float")) _val = CovertDW2Double(int1, int2);
                            if (cboTypeAnalog.Text.Equals("Float Swap")) _val = CovertDW2DoubleSwap(int1, int2);
                            _val = Math.Round(_val, 3);
                            lstData.Add(_val);
                            i += 1;
                        }
                        if (dgAnalogs.Rows.Count != lstData.Count)
                        {
                            dgAnalogs.Rows.Clear();
                            int idr = iStart;
                            for (int i = 0; i < lstData.Count; i++)
                            {
                                dgAnalogs.Rows.Add(idr + 30000, lstData[i]);
                                idr += 2;
                            }
                        }
                        else
                        {
                            int idr = iStart;
                            for (int i = 0; i < lstData.Count; i++)
                            {
                                dgAnalogs.Rows[i].Cells[0].Value = idr + 30000;
                                dgAnalogs.Rows[i].Cells[1].Value = lstData[i];
                                idr += 2;
                            }
                        }
                    }
                    else if (cboTypeAnalog.Text.Equals("Binary"))
                    {
                        if (dgAnalogs.Rows.Count != iLen)
                        {
                            dgAnalogs.Rows.Clear();
                            for (int i = 0; i < iLen; i++)
                            {
                                dgAnalogs.Rows.Add(iStart + i + 30000, Convert.ToString(AnalogInputs[iStart + i], 2).PadLeft(16, '0'));
                            }
                        }
                        else
                        {
                            for (int i = 0; i < iLen; i++)
                            {
                                dgAnalogs.Rows[i].Cells[0].Value = iStart + i + 30000;
                                dgAnalogs.Rows[i].Cells[1].Value = Convert.ToString(AnalogInputs[iStart + i], 2).PadLeft(16, '0');
                            }
                        }
                    }
                    else if (cboTypeAnalog.Text.Equals("Double Float") || cboTypeAnalog.Text.Equals("Double Float Swap"))
                    {
                        List<double> lstData = new List<double>();
                        for (int i = 0; i < iLen; i++)
                        {
                            short int1 = (short)AnalogInputs[iStart + i];
                            short int2 = (short)AnalogInputs[iStart + i + 1];
                            short int3 = (short)AnalogInputs[iStart + i + 2];
                            short int4 = (short)AnalogInputs[iStart + i + 3];
                            double _val = 0;
                            if (cboTypeAnalog.Text.Equals("Double Float")) _val = CovertQW2Double(int1, int2, int3, int4);
                            if (cboTypeAnalog.Text.Equals("Double Float Swap")) _val = CovertQW2DoubleSwap(int1, int2, int3, int4);
                            _val = Math.Round(_val, 3);
                            lstData.Add(_val);
                            i += 3;
                        }
                        if (dgAnalogs.Rows.Count != lstData.Count)
                        {
                            dgAnalogs.Rows.Clear();
                            int idr = iStart;
                            for (int i = 0; i < lstData.Count; i++)
                            {
                                dgAnalogs.Rows.Add(idr + 30000, lstData[i]);
                                idr += 4;
                            }
                        }
                        else
                        {
                            int idr = iStart;
                            for (int i = 0; i < lstData.Count; i++)
                            {
                                dgAnalogs.Rows[i].Cells[0].Value = idr + 30000;
                                dgAnalogs.Rows[i].Cells[1].Value = lstData[i];
                                idr += 4;
                            }
                        }
                    }                    
                }
                catch (Exception ex)
                {
                    ex.ToString();
                }
            }
            else if (sTab.Equals("Digital Inputs"))
            {
                int iStart = int.Parse(txtStartDigital.Text);
                try
                {
                    int iLen = int.Parse(txtLenDigital.Text);
                    bool[] Values = ModClient.ReadDiscreteInputs(iStart - 1, iLen);
                    for (int i = 0; i < Values.Length; i++)
                    {
                        DigitalInputs[iStart + i] = Values[i];
                    }
                    if (dgDigitals.Rows.Count != iLen)
                    {
                        dgDigitals.Rows.Clear();
                        for (int i = 0; i < iLen; i++)
                        {
                            string sval = DigitalInputs[iStart + i].ToString();
                            if (cboTypeDigital.Text == "Binary")
                            {
                                if (DigitalInputs[iStart + i] == true) sval = "1"; 
                                if (DigitalInputs[iStart + i] == false) sval = "0"; 
                            }
                            dgDigitals.Rows.Add(iStart + i + 10000, sval);
                        }
                    }
                    else
                    {
                        for (int i = 0; i < iLen; i++)
                        {
                            dgDigitals.Rows[i].Cells[0].Value = iStart + i + 10000;
                            string sval = DigitalInputs[iStart + i].ToString();
                            if (cboTypeDigital.Text == "Binary")
                            {
                                if (DigitalInputs[iStart + i] == true) sval = "1";
                                if (DigitalInputs[iStart + i] == false) sval = "0";
                            }
                            dgDigitals.Rows[i].Cells[1].Value = sval;
                        }
                    }
                }
                catch (Exception ex)
                {
                    ex.ToString();
                }
            }
            else if (sTab.Equals("Coil Outputs"))
            {
                int iStart = int.Parse(txtStartCoil.Text);
                try
                {
                    int iLen = int.Parse(txtLenCoil.Text);
                    bool[] Values = ModClient.ReadCoils(iStart - 1, iLen);
                    for (int i = 0; i < Values.Length; i++)
                    {
                        CoilOutputs[iStart + i] = Values[i];
                    }
                    if (dgCoils.Rows.Count != iLen)
                    {
                        dgCoils.Rows.Clear();
                        for (int i = 0; i < iLen; i++)
                        {
                            string sval = CoilOutputs[iStart + i].ToString();
                            if (cboTypeCoil.Text == "Binary")
                            {
                                if (CoilOutputs[iStart + i] == true) sval = "1";
                                if (CoilOutputs[iStart + i] == false) sval = "0";
                            }
                            dgCoils.Rows.Add(iStart + i, sval);
                        }
                    }
                    else
                    {
                        for (int i = 0; i < iLen; i++)
                        {
                            dgCoils.Rows[i].Cells[0].Value = iStart + i;
                            string sval = CoilOutputs[iStart + i].ToString();
                            if (cboTypeCoil.Text == "Binary")
                            {
                                if (CoilOutputs[iStart + i] == true) sval = "1";
                                if (CoilOutputs[iStart + i] == false) sval = "0";
                            }
                            dgCoils.Rows[i].Cells[1].Value = sval;
                        }
                    }
                }
                catch (Exception ex)
                {
                    ex.ToString();
                }
            }
            if (btnConnect.Text.Equals("Disconnect"))
            {
                timerPoll.Start();
            }
        }

        private void CmsWriteCoil_Opening(object sender, CancelEventArgs e)
        {
            if (dgCoils.SelectedCells.Count > 0)
            {
                int idx = dgCoils.SelectedCells[0].RowIndex;
                string val = dgCoils.Rows[idx].Cells[1].Value.ToString();
                if (val=="True" || val=="1")
                {
                    cmsWriteCoil.Items[0].Enabled = false;
                    cmsWriteCoil.Items[1].Enabled = true;
                } else
                {
                    cmsWriteCoil.Items[0].Enabled = true;
                    cmsWriteCoil.Items[1].Enabled = false;
                }
            }
        }

        private void DgCoils_CellMouseDoubleClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            cmsWriteCoil.Show(Cursor.Position);
        }

        private void TrueToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (dgCoils.SelectedCells.Count > 0)
            {
                int idx = dgCoils.SelectedCells[0].RowIndex;
                if (rdbClient.Checked || rdbRtuMaster.Checked)
                {
                    ModClient.WriteSingleCoil((int)dgCoils.Rows[idx].Cells[0].Value - 1, true);
                } 
                else if (rdbServer.Checked || rdbRtuSlave.Checked)
                {
                    ModServer.coils[(int)dgCoils.Rows[idx].Cells[0].Value] = true;
                    if (cboTypeCoil.Text == "Binary") { dgCoils.Rows[idx].Cells[1].Value = "1"; } else { dgCoils.Rows[idx].Cells[1].Value = true.ToString(); }                    
                }                
            }
        }

        private void FalseToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (dgCoils.SelectedCells.Count > 0)
            {
                int idx = dgCoils.SelectedCells[0].RowIndex;
                if (rdbClient.Checked || rdbRtuMaster.Checked)
                {
                    ModClient.WriteSingleCoil((int)dgCoils.Rows[idx].Cells[0].Value - 1, false);
                }
                else if (rdbServer.Checked || rdbRtuSlave.Checked)
                {
                    ModServer.coils[(int)dgCoils.Rows[idx].Cells[0].Value] = false;
                    if (cboTypeCoil.Text == "Binary") { dgCoils.Rows[idx].Cells[1].Value = "0"; } else { dgCoils.Rows[idx].Cells[1].Value = false.ToString(); }
                }
            }
        }

        private void DgHoldings_CellMouseDoubleClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            if (rdbClient.Checked || rdbRtuMaster.Checked)
            {
                //grpChangeValue.Location = Cursor.Position;
                if (dgHoldings.SelectedCells.Count > 0)
                {
                    int idx = dgHoldings.SelectedCells[0].RowIndex;
                    txtNewValue.Text = dgHoldings.Rows[idx].Cells[1].Value.ToString();
                    grpChangeValue.Visible = true;
                }
            }                      
        }

        private void BtnOkChangeValue_Click(object sender, EventArgs e)
        {
            if (dgHoldings.SelectedCells.Count > 0)
            {
                try
                {
                    int idx = dgHoldings.SelectedCells[0].RowIndex;
                    if (cboTypeHolding.Text.Equals("Decimal"))
                    {
                        ModClient.WriteSingleRegister((int)dgHoldings.Rows[idx].Cells[0].Value - 40001, int.Parse(txtNewValue.Text));
                    }
                    else if (cboTypeHolding.Text.Equals("Float") || cboTypeHolding.Text.Equals("Float Swap"))
                    {
                        float dVal = float.Parse(txtNewValue.Text);
                        //byte[] byVals = BitConverter.GetBytes(dVal);
                        //if (BitConverter.IsLittleEndian) { Array.Reverse(byVals); }

                        //byte[] bytes1 = { byVals[1], byVals[0] };
                        //short int1 = BitConverter.ToInt16(bytes1, 0);
                        //byte[] bytes2 = { byVals[3], byVals[2] };
                        //short int2 = BitConverter.ToInt16(bytes2, 0);

                        short[] svalues = new short[2];
                        if (cboTypeHolding.Text.Equals("Float")) svalues = ConvertFloat2DW(dVal);
                        if (cboTypeHolding.Text.Equals("Float Swap")) svalues = ConvertFloat2DWSwap(dVal);

                        int[] values = new int[2];
                        values[0] = svalues[0]; values[1] = svalues[1];
                                                
                        ModClient.WriteMultipleRegisters((int)dgHoldings.Rows[idx].Cells[0].Value - 40001, values);
                    }
                    else if (cboTypeHolding.Text.Equals("Binary"))
                    {
                        ModClient.WriteSingleRegister((int)dgHoldings.Rows[idx].Cells[0].Value - 40001, Convert.ToInt16(txtNewValue.Text,2));
                    }
                    else if (cboTypeHolding.Text.Equals("Double Float") || cboTypeHolding.Text.Equals("Double Float Swap"))
                    {
                        double dVal = double.Parse(txtNewValue.Text);
                        short[] svalues = new short[4];
                        if (cboTypeHolding.Text.Equals("Double Float")) svalues = ConvertDouble2QW(dVal);
                        if (cboTypeHolding.Text.Equals("Double Float Swap")) svalues = ConvertDouble2QWSwap(dVal);

                        int[] values = new int[4];
                        values[0] = svalues[0]; values[1] = svalues[1];
                        values[2] = svalues[2]; values[3] = svalues[3];

                        ModClient.WriteMultipleRegisters((int)dgHoldings.Rows[idx].Cells[0].Value - 40001, values);
                    }
                } catch (Exception ex)
                {
                    ex.ToString();
                }                               
            }
            grpChangeValue.Visible = false;
        }

        private void BtnCancelChangeValue_Click(object sender, EventArgs e)
        {
            grpChangeValue.Visible = false;
        }

        private void RdbServer_CheckedChanged(object sender, EventArgs e)
        {
            if (rdbServer.Checked)
            {
                txtIp.Enabled = false;
                txtPollInterval.Enabled = false;
                btnConnect.Visible = false;
                btnStart.Visible = true;
                dgAnalogs.Columns[1].ReadOnly = false;
                dgHoldings.Columns[1].ReadOnly = false;
                panelTCP.Visible = true;
                panelRTU.Visible = false;
            }
        }

        private void RdbClient_CheckedChanged(object sender, EventArgs e)
        {
            if (rdbClient.Checked)
            {
                txtIp.Enabled = true;
                txtPollInterval.Enabled = true;
                btnConnect.Visible = true;
                btnStart.Visible = false;
                dgAnalogs.Columns[1].ReadOnly = true;
                dgHoldings.Columns[1].ReadOnly = true;
                panelTCP.Visible = true;
                panelRTU.Visible = false;
            }
        }

        private void DgDigitals_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            if (rdbServer.Checked || rdbRtuSlave.Checked)
            {
                cmsWriteDigital.Show(Cursor.Position);
            }            
        }

        private void BtnStart_Click(object sender, EventArgs e)
        {
            txtStatus.Text = "";
            try
            {
                if (btnStart.Text.Equals("START"))
                {
                    //dgCoils.Rows.Clear();
                    //dgDigitals.Rows.Clear();
                    //dgAnalogs.Rows.Clear();
                    //dgHoldings.Rows.Clear();

                    ModServer = new ModbusServer();
                    if (rdbServer.Checked)
                    {
                        ModServer.Port = int.Parse(txtPort.Text);
                        ModServer.SerialFlag = false;
                    }
                    else if (rdbRtuSlave.Checked)
                    {
                        //for(int i = 0; i < cboUnitID.Items.Count; i++)
                        //{
                        //    ModbusServer mod = new ModbusServer();
                        //    ModbusServers.Add(mod);
                        //}
                        //ModServer = ModbusServers[0];

                        ModServer.SerialPort = cboRtuPort.Text;
                        ModServer.SerialFlag = true;
                        ModServer.Baudrate = int.Parse(cboRtuBaud.Text);
                        switch (cboRtuParity.Text)
                        {
                            case "None":
                                ModServer.Parity = Parity.None;
                                break;
                            case "Even":
                                ModServer.Parity = Parity.Even;
                                break;
                            case "Odd":
                                ModServer.Parity = Parity.Odd;
                                break;
                            case "Space":
                                ModServer.Parity = Parity.Space;
                                break;
                            case "Mark":
                                ModServer.Parity = Parity.Mark;
                                break;
                        }
                    }
                    ModServer.UnitIdentifier = byte.Parse(cboUnitID.Text);
                    ModServer.HoldingRegistersChanged += ModServer_HoldingRegistersChanged;
                    ModServer.CoilsChanged += ModServer_CoilsChanged;
                    ModServer.Listen();
                    btnStart.Text = "STOP";
                    panelTCP.Enabled = false;
                    panelRTU.Enabled = false;
                    panelRadio.Enabled = false;
                    RefreshDgTags();
                    tabControl1.Enabled = true;
                }
                else if (btnStart.Text.Equals("STOP"))
                {
                    ModServer.StopListening();
                    ModServer = null;
                    btnStart.Text = "START";
                    panelTCP.Enabled = true;
                    panelRTU.Enabled = true;
                    panelRadio.Enabled = true;
                    tabControl1.Enabled = false;
                }
            }
            catch (Exception ex){
                txtStatus.Text = "Error: " + ex.Message;
            }
        }

        private void CmsWriteDigital_Opening(object sender, CancelEventArgs e)
        {
            if (dgDigitals.SelectedCells.Count > 0)
            {
                int idx = dgDigitals.SelectedCells[0].RowIndex;
                string val = dgDigitals.Rows[idx].Cells[1].Value.ToString();
                if (val=="True" || val=="1")
                {
                    cmsWriteDigital.Items[0].Enabled = false;
                    cmsWriteDigital.Items[1].Enabled = true;
                }
                else
                {
                    cmsWriteDigital.Items[0].Enabled = true;
                    cmsWriteDigital.Items[1].Enabled = false;
                }
            }
        }

        private void TrueMenuDigital_Click(object sender, EventArgs e)
        {
            if (dgDigitals.SelectedCells.Count > 0)
            {
                int idx = dgDigitals.SelectedCells[0].RowIndex;
                if (rdbServer.Checked || rdbRtuSlave.Checked)
                {
                    ModServer.discreteInputs[(int)dgDigitals.Rows[idx].Cells[0].Value - 10000] = true;
                    if (cboTypeDigital.Text == "Binary") { dgDigitals.Rows[idx].Cells[1].Value = "1"; } else { dgDigitals.Rows[idx].Cells[1].Value = true.ToString(); }
                }
            }
        }

        private void FalseMenuDigital_Click(object sender, EventArgs e)
        {
            if (dgDigitals.SelectedCells.Count > 0)
            {
                int idx = dgDigitals.SelectedCells[0].RowIndex;
                if (rdbServer.Checked || rdbRtuSlave.Checked)
                {
                    ModServer.discreteInputs[(int)dgDigitals.Rows[idx].Cells[0].Value - 10000] = false;
                    if (cboTypeDigital.Text == "Binary") { dgDigitals.Rows[idx].Cells[1].Value = "0"; } else { dgDigitals.Rows[idx].Cells[1].Value = false.ToString(); }
                }
            }
        }

        private void DgDigitals_CellMouseDoubleClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            cmsWriteDigital.Show(Cursor.Position);
        }

        private void ModServer_CoilsChanged(int coil, int numberOfCoils)
        {
            if (dgCoils.InvokeRequired)
            {
                //Invoke only the ui-interaction code
                dgCoils.Invoke(new MethodInvoker(this.RefreshDgCoil2));
            }
            else
            {
                RefreshDgCoil2();
            }
            //throw new NotImplementedException();
        }

        private void ModServer_HoldingRegistersChanged(int register, int numberOfRegisters)
        {
            if (dgHoldings.InvokeRequired)
            {
                //Invoke only the ui-interaction code
                dgHoldings.Invoke(new MethodInvoker(this.RefreshDgHolding2));
            }
            else
            {
                RefreshDgHolding2();
            }            
            //throw new NotImplementedException();
        }

        private void RefreshDgTags()
        {
            try
            {
                RefreshDgCoil2();
                RefreshDgDigital(null,null);
                RefreshDgAnalog(null, null);
                RefreshDgHolding2();
            } catch (Exception ex)
            {
                ex.ToString();
            }
        }

        private void RefreshDgCoil(object sender, EventArgs e)
        {
            RefreshDgCoil2();
        }

        private void RefreshDgCoil2()
        {
            if (rdbServer.Checked || rdbRtuSlave.Checked)
            {
                dgCoils.Rows.Clear();
                int iStart;
                int iLen;
                iStart = int.Parse(txtStartCoil.Text);
                iLen = int.Parse(txtLenCoil.Text);
                for (int i = 0; i < iLen; i++)
                {
                    string sval="";
                    if (cboTypeCoil.Text == "Binary")
                    {
                        if (ModServer.coils[iStart + i] == true) { sval = "1"; } else { sval = "0"; }
                    }
                    else { sval = ModServer.coils[iStart + i].ToString(); }
                    dgCoils.Rows.Add(iStart + i, sval);
                }
            }
        }

        private void RefreshDgDigital(object sender, EventArgs e)
        {
            if (rdbServer.Checked || rdbRtuSlave.Checked)
            {
                dgDigitals.Rows.Clear();
                int iStart;
                int iLen;
                iStart = int.Parse(txtStartDigital.Text);
                iLen = int.Parse(txtLenDigital.Text);
                for (int i = 0; i < iLen; i++)
                {
                    string sval = "";
                    if (cboTypeDigital.Text == "Binary")
                    {
                        if (ModServer.discreteInputs[iStart + i] == true) { sval = "1"; } else { sval = "0"; }
                    }
                    else { sval = ModServer.discreteInputs[iStart + i].ToString(); }
                    dgDigitals.Rows.Add(iStart + i + 10000, sval);
                }
            }
        }
        private void RefreshDgAnalog(object sender, EventArgs e)
        {
            if (rdbServer.Checked || rdbRtuSlave.Checked)
            {
                dgAnalogs.Rows.Clear();
                int iStart;
                int iLen;
                iStart = int.Parse(txtStartAnalog.Text);
                iLen = int.Parse(txtLenAnalog.Text);
                if (cboTypeAnalog.Text.Equals("Decimal"))
                {
                    for (int i = 0; i < iLen; i++)
                    {
                        dgAnalogs.Rows.Add(iStart + i + 30000, ModServer.inputRegisters[iStart + i].ToString());
                    }
                }
                else if (cboTypeAnalog.Text.Equals("Float") || cboTypeAnalog.Text.Equals("Float Swap"))
                {
                    for (int i = 0; i < iLen; i++)
                    {
                        double dVal = 0;
                        if (cboTypeAnalog.Text.Equals("Float")) dVal = CovertDW2Double(ModServer.inputRegisters[iStart + i], ModServer.inputRegisters[iStart + i + 1]);
                        if (cboTypeAnalog.Text.Equals("Float Swap")) dVal = CovertDW2DoubleSwap(ModServer.inputRegisters[iStart + i], ModServer.inputRegisters[iStart + i + 1]);
                        dgAnalogs.Rows.Add(iStart + i + 30000, dVal);
                        i += 1;
                    }
                }
                else if (cboTypeAnalog.Text.Equals("Binary"))
                {
                    for (int i = 0; i < iLen; i++)
                    {
                        dgAnalogs.Rows.Add(iStart + i + 30000, Convert.ToString(ModServer.inputRegisters[iStart + i], 2).PadLeft(16, '0'));
                    }
                }
                else if (cboTypeAnalog.Text.Equals("Double Float") || cboTypeAnalog.Text.Equals("Double Float Swap"))
                {
                    for (int i = 0; i < iLen; i++)
                    {
                        double dVal = 0;
                        if (cboTypeAnalog.Text.Equals("Double Float")) dVal = CovertQW2Double(ModServer.inputRegisters[iStart + i], ModServer.inputRegisters[iStart + i + 1], ModServer.inputRegisters[iStart + i + 2], ModServer.inputRegisters[iStart + i + 3]);
                        if (cboTypeAnalog.Text.Equals("Double Float Swap")) dVal = CovertQW2DoubleSwap(ModServer.inputRegisters[iStart + i], ModServer.inputRegisters[iStart + i + 1], ModServer.inputRegisters[iStart + i + 2], ModServer.inputRegisters[iStart + i + 3]);
                        dgAnalogs.Rows.Add(iStart + i + 30000, dVal);
                        i += 3;
                    }
                }
            }                
        }


        private void RefreshDgHolding(object sender, EventArgs e)
        {
            RefreshDgHolding2();
        }

        private void RefreshDgHolding2()
        {
            if (rdbServer.Checked || rdbRtuSlave.Checked)
            {
                dgHoldings.Rows.Clear();
                
                int iStart;
                int iLen;
                iStart = int.Parse(txtStartHolding.Text);
                iLen = int.Parse(txtLenHolding.Text);
                if (cboTypeHolding.Text.Equals("Decimal"))
                {
                    for (int i = 0; i < iLen; i++)
                    {
                        dgHoldings.Rows.Add(iStart + i + 40000, ModServer.holdingRegisters[iStart + i].ToString());
                    }
                }
                else if (cboTypeHolding.Text.Equals("Float") || cboTypeHolding.Text.Equals("Float Swap"))
                {
                    for (int i = 0; i < iLen; i++)
                    {
                        double dVal = 0;
                        if(cboTypeHolding.Text.Equals("Float")) dVal = CovertDW2Double(ModServer.holdingRegisters[iStart + i], ModServer.holdingRegisters[iStart + i + 1]);
                        if(cboTypeHolding.Text.Equals("Float Swap")) dVal = CovertDW2DoubleSwap(ModServer.holdingRegisters[iStart + i], ModServer.holdingRegisters[iStart + i + 1]);
                        dgHoldings.Rows.Add(iStart + i + 40000, dVal);
                        i += 1;
                    }
                }
                else if (cboTypeHolding.Text.Equals("Binary"))
                {
                    for (int i = 0; i < iLen; i++)
                    {
                        dgHoldings.Rows.Add(iStart + i + 40000, Convert.ToString(ModServer.holdingRegisters[iStart + i], 2).PadLeft(16, '0'));
                    }
                }
                else if (cboTypeHolding.Text.Equals("Double Float") || cboTypeHolding.Text.Equals("Double Float Swap"))
                {
                    for (int i = 0; i < iLen; i++)
                    {
                        double dVal = 0;
                        if (cboTypeHolding.Text.Equals("Double Float")) dVal = CovertQW2Double(ModServer.holdingRegisters[iStart + i], ModServer.holdingRegisters[iStart + i + 1], ModServer.holdingRegisters[iStart + i + 2], ModServer.holdingRegisters[iStart + i + 3]);
                        if (cboTypeHolding.Text.Equals("Double Float Swap")) dVal = CovertQW2DoubleSwap(ModServer.holdingRegisters[iStart + i], ModServer.holdingRegisters[iStart + i + 1], ModServer.holdingRegisters[iStart + i + 2], ModServer.holdingRegisters[iStart + i + 3]);
                        dgHoldings.Rows.Add(iStart + i + 40000, dVal);
                        i += 3;
                    }
                }
            }            
        }

        private string ConvertDec2Bin(int val)
        {
            char[] bits = new char[16];
            int i = 0;
            while (val != 0)
            {
                bits[i++] = (val & 1) == 1 ? '1' : '0';
                val >>= 1;
            }

            Array.Reverse(bits, 0, i);
            return new string(bits);
        }
        private double CovertDW2Double(short int1, short int2)
        {
            byte[] intBytes1 = BitConverter.GetBytes(int1);
            if (BitConverter.IsLittleEndian) Array.Reverse(intBytes1);
            byte[] result1 = intBytes1;
            byte[] intBytes2 = BitConverter.GetBytes(int2);
            if (BitConverter.IsLittleEndian) Array.Reverse(intBytes2);
            byte[] result2 = intBytes2;
            byte[] _bytes = new byte[4];
            _bytes[0] = intBytes1[1];
            _bytes[1] = intBytes1[0];
            _bytes[2] = intBytes2[1];
            _bytes[3] = intBytes2[0];
            double _val = BitConverter.ToSingle(_bytes, 0);
            _val = Math.Round(_val, 3);

            return _val;
        }
        private double CovertDW2DoubleSwap(short int1, short int2)
        {
            byte[] intBytes1 = BitConverter.GetBytes(int1);
            if (BitConverter.IsLittleEndian) Array.Reverse(intBytes1);
            byte[] result1 = intBytes1;
            byte[] intBytes2 = BitConverter.GetBytes(int2);
            if (BitConverter.IsLittleEndian) Array.Reverse(intBytes2);
            byte[] result2 = intBytes2;
            byte[] _bytes = new byte[4];
            _bytes[0] = intBytes2[1];
            _bytes[1] = intBytes2[0];
            _bytes[2] = intBytes1[1];
            _bytes[3] = intBytes1[0];
            double _val = BitConverter.ToSingle(_bytes, 0);
            _val = Math.Round(_val, 3);

            return _val;
        }
        private short[] ConvertFloat2DW(float fVal)
        {
            byte[] byVals = BitConverter.GetBytes(fVal);
            if (BitConverter.IsLittleEndian) { Array.Reverse(byVals); }

            byte[] bytes1 = { byVals[1], byVals[0] };
            short int1 = BitConverter.ToInt16(bytes1, 0);
            byte[] bytes2 = { byVals[3], byVals[2] };
            short int2 = BitConverter.ToInt16(bytes2, 0);

            short[] values = new short[2];
            values[0] = int2; values[1] = int1;

            return values;
        }

        private short[] ConvertFloat2DWSwap(float fVal)
        {
            byte[] byVals = BitConverter.GetBytes(fVal);
            if (BitConverter.IsLittleEndian) { Array.Reverse(byVals); }

            byte[] bytes1 = { byVals[1], byVals[0] };
            short int1 = BitConverter.ToInt16(bytes1, 0);
            byte[] bytes2 = { byVals[3], byVals[2] };
            short int2 = BitConverter.ToInt16(bytes2, 0);

            short[] values = new short[2];
            values[0] = int1; values[1] = int2;

            return values;
        }

        private double CovertQW2Double(short int1, short int2, short int3, short int4)
        {
            byte[] intBytes1 = BitConverter.GetBytes(int1);
            if (BitConverter.IsLittleEndian) Array.Reverse(intBytes1);
            byte[] result1 = intBytes1;
            byte[] intBytes2 = BitConverter.GetBytes(int2);
            if (BitConverter.IsLittleEndian) Array.Reverse(intBytes2);
            byte[] result2 = intBytes2;
            byte[] intBytes3 = BitConverter.GetBytes(int3);
            if (BitConverter.IsLittleEndian) Array.Reverse(intBytes3);
            byte[] result3 = intBytes3;
            byte[] intBytes4 = BitConverter.GetBytes(int4);
            if (BitConverter.IsLittleEndian) Array.Reverse(intBytes4);
            byte[] result4 = intBytes4;
            byte[] _bytes = new byte[8];
            _bytes[0] = intBytes1[1];
            _bytes[1] = intBytes1[0];
            _bytes[2] = intBytes2[1];
            _bytes[3] = intBytes2[0];
            _bytes[4] = intBytes3[1];
            _bytes[5] = intBytes3[0];
            _bytes[6] = intBytes4[1];
            _bytes[7] = intBytes4[0];
            long l_val = BitConverter.ToInt64(_bytes, 0);
            double _val = BitConverter.Int64BitsToDouble(l_val);
            _val = Math.Round(_val, 3);

            return _val;
        }
        private short[] ConvertDouble2QW(double dVal)
        {
            long l_val = BitConverter.DoubleToInt64Bits(dVal);
            byte[] byVals = BitConverter.GetBytes(l_val);
            if (BitConverter.IsLittleEndian) { Array.Reverse(byVals); }

            byte[] bytes1 = { byVals[1], byVals[0] };
            short int1 = BitConverter.ToInt16(bytes1, 0);
            byte[] bytes2 = { byVals[3], byVals[2] };
            short int2 = BitConverter.ToInt16(bytes2, 0);
            byte[] bytes3 = { byVals[5], byVals[4] };
            short int3 = BitConverter.ToInt16(bytes3, 0);
            byte[] bytes4 = { byVals[7], byVals[6] };
            short int4 = BitConverter.ToInt16(bytes4, 0);

            short[] values = new short[4];
            values[0] = int4; 
            values[1] = int3;
            values[2] = int2; 
            values[3] = int1;

            return values;
        }
        private double CovertQW2DoubleSwap(short int1, short int2, short int3, short int4)
        {
            byte[] intBytes1 = BitConverter.GetBytes(int1);
            if (BitConverter.IsLittleEndian) Array.Reverse(intBytes1);
            byte[] result1 = intBytes1;
            byte[] intBytes2 = BitConverter.GetBytes(int2);
            if (BitConverter.IsLittleEndian) Array.Reverse(intBytes2);
            byte[] result2 = intBytes2;
            byte[] intBytes3 = BitConverter.GetBytes(int3);
            if (BitConverter.IsLittleEndian) Array.Reverse(intBytes3);
            byte[] result3 = intBytes3;
            byte[] intBytes4 = BitConverter.GetBytes(int4);
            if (BitConverter.IsLittleEndian) Array.Reverse(intBytes4);
            byte[] result4 = intBytes4;
            byte[] _bytes = new byte[8];
            _bytes[0] = intBytes4[1];
            _bytes[1] = intBytes4[0];
            _bytes[2] = intBytes3[1];
            _bytes[3] = intBytes3[0];
            _bytes[4] = intBytes2[1];
            _bytes[5] = intBytes2[0];
            _bytes[6] = intBytes1[1];
            _bytes[7] = intBytes1[0];
            long l_val = BitConverter.ToInt64(_bytes, 0);
            double _val = BitConverter.Int64BitsToDouble(l_val);
            _val = Math.Round(_val, 3);

            return _val;
        }
        private short[] ConvertDouble2QWSwap(double dVal)
        {
            long l_val = BitConverter.DoubleToInt64Bits(dVal);
            byte[] byVals = BitConverter.GetBytes(l_val);
            if (BitConverter.IsLittleEndian) { Array.Reverse(byVals); }

            byte[] bytes1 = { byVals[1], byVals[0] };
            short int1 = BitConverter.ToInt16(bytes1, 0);
            byte[] bytes2 = { byVals[3], byVals[2] };
            short int2 = BitConverter.ToInt16(bytes2, 0);
            byte[] bytes3 = { byVals[5], byVals[4] };
            short int3 = BitConverter.ToInt16(bytes3, 0);
            byte[] bytes4 = { byVals[7], byVals[6] };
            short int4 = BitConverter.ToInt16(bytes4, 0);

            short[] values = new short[4];
            values[0] = int1;
            values[1] = int2;
            values[2] = int3;
            values[3] = int4;

            return values;
        }

        

        private void DgAnalogs_CellValueChanged(object sender, DataGridViewCellEventArgs e)
        {
            if (rdbServer.Checked || rdbRtuSlave.Checked)
            {
                int idx = dgAnalogs.SelectedCells[0].RowIndex;
                int iReg = (int)dgAnalogs.Rows[idx].Cells[0].Value - 30000;
                if (cboTypeAnalog.Text.Equals("Decimal"))
                {
                    try
                    {
                        short iVal = short.Parse(dgAnalogs.Rows[idx].Cells[1].Value.ToString());
                        ModServer.inputRegisters[iReg] = iVal;
                    }
                    catch (Exception ex)
                    {
                        ex.ToString();
                        dgAnalogs.Rows[idx].Cells[1].Value = ModServer.inputRegisters[iReg];
                    }                    
                }
                else if (cboTypeAnalog.Text.Equals("Float") || cboTypeAnalog.Text.Equals("Float Swap"))
                {
                    try
                    {
                        float fVal = float.Parse(dgAnalogs.Rows[idx].Cells[1].Value.ToString());
                        short[] arInt = new short[2];
                        if (cboTypeAnalog.Text.Equals("Float")) arInt = ConvertFloat2DW(fVal);
                        if (cboTypeAnalog.Text.Equals("Float Swap")) arInt = ConvertFloat2DWSwap(fVal);
                        ModServer.inputRegisters[iReg] = arInt[0];
                        ModServer.inputRegisters[iReg+1] = arInt[1];
                    }
                    catch (Exception ex)
                    {
                        ex.ToString();
                        double dVal = 0;
                        if (cboTypeAnalog.Text.Equals("Float")) dVal = CovertDW2Double(ModServer.inputRegisters[iReg], ModServer.inputRegisters[iReg+1]);
                        if (cboTypeAnalog.Text.Equals("Float Swap")) dVal = CovertDW2DoubleSwap(ModServer.inputRegisters[iReg], ModServer.inputRegisters[iReg+1]);
                        dgAnalogs.Rows[idx].Cells[1].Value = dVal;
                    }
                }
                else if (cboTypeAnalog.Text.Equals("Binary"))
                {
                    try
                    {
                        short iVal = Convert.ToInt16(dgAnalogs.Rows[idx].Cells[1].Value.ToString(), 2);
                        ModServer.inputRegisters[iReg] = iVal;
                    }
                    catch (Exception ex)
                    {
                        ex.ToString();
                        dgAnalogs.Rows[idx].Cells[1].Value = Convert.ToString(ModServer.inputRegisters[iReg],2).PadLeft(16,'0');
                    }
                }
                else if (cboTypeAnalog.Text.Equals("Double Float") || cboTypeAnalog.Text.Equals("Double Float Swap"))
                {
                    try
                    {
                        double dVal = double.Parse(dgAnalogs.Rows[idx].Cells[1].Value.ToString());
                        short[] arInt = new short[4];
                        if (cboTypeAnalog.Text.Equals("Double Float")) arInt = ConvertDouble2QW(dVal);
                        if (cboTypeAnalog.Text.Equals("Double Float Swap")) arInt = ConvertDouble2QWSwap(dVal);
                        ModServer.inputRegisters[iReg] = arInt[0];
                        ModServer.inputRegisters[iReg + 1] = arInt[1];
                        ModServer.inputRegisters[iReg + 2] = arInt[2];
                        ModServer.inputRegisters[iReg + 3] = arInt[3];
                    }
                    catch (Exception ex)
                    {
                        ex.ToString();
                        double dVal = 0;
                        if (cboTypeAnalog.Text.Equals("Double Float")) dVal = CovertQW2Double(ModServer.inputRegisters[iReg], ModServer.inputRegisters[iReg + 1], ModServer.inputRegisters[iReg + 2], ModServer.inputRegisters[iReg + 3]);
                        if (cboTypeAnalog.Text.Equals("Double Float Swap")) dVal = CovertQW2DoubleSwap(ModServer.inputRegisters[iReg], ModServer.inputRegisters[iReg + 1], ModServer.inputRegisters[iReg + 2], ModServer.inputRegisters[iReg + 3]);
                        dgAnalogs.Rows[idx].Cells[1].Value = dVal;
                    }
                }
            }
        }

        private void DgHoldings_CellValueChanged(object sender, DataGridViewCellEventArgs e)
        {
            if (rdbServer.Checked || rdbRtuSlave.Checked)
            {
                int idx = dgHoldings.SelectedCells[0].RowIndex;
                int iReg = (int)dgHoldings.Rows[idx].Cells[0].Value - 40000;
                if (cboTypeHolding.Text.Equals("Decimal"))
                {
                    try
                    {
                        short iVal = short.Parse(dgHoldings.Rows[idx].Cells[1].Value.ToString());
                        ModServer.holdingRegisters[iReg] = iVal;
                    }
                    catch (Exception ex)
                    {
                        ex.ToString();
                        dgHoldings.Rows[idx].Cells[1].Value = ModServer.holdingRegisters[iReg];
                    }
                }
                else if (cboTypeHolding.Text.Equals("Float") || cboTypeHolding.Text.Equals("Float Swap"))
                {
                    try
                    {
                        float fVal = float.Parse(dgHoldings.Rows[idx].Cells[1].Value.ToString());
                        short[] arInt = new short[2];
                        if (cboTypeHolding.Text.Equals("Float")) arInt = ConvertFloat2DW(fVal);
                        if (cboTypeHolding.Text.Equals("Float Swap")) arInt = ConvertFloat2DWSwap(fVal);
                        ModServer.holdingRegisters[iReg] = arInt[0];
                        ModServer.holdingRegisters[iReg + 1] = arInt[1];
                    }
                    catch (Exception ex)
                    {
                        ex.ToString();
                        double dVal =0;
                        if (cboTypeHolding.Text.Equals("Float")) dVal = CovertDW2Double(ModServer.holdingRegisters[iReg], ModServer.holdingRegisters[iReg + 1]);
                        if (cboTypeHolding.Text.Equals("Float Swap")) dVal = CovertDW2DoubleSwap(ModServer.holdingRegisters[iReg], ModServer.holdingRegisters[iReg + 1]);
                        dgHoldings.Rows[idx].Cells[1].Value = dVal;
                    }
                }
                else if (cboTypeHolding.Text.Equals("Binary"))
                {
                    try
                    {
                        short iVal = Convert.ToInt16(dgHoldings.Rows[idx].Cells[1].Value.ToString(), 2);
                        ModServer.holdingRegisters[iReg] = iVal;
                    }
                    catch (Exception ex)
                    {
                        ex.ToString();
                        dgHoldings.Rows[idx].Cells[1].Value = Convert.ToString(ModServer.holdingRegisters[iReg], 2).PadLeft(16, '0');
                    }
                }
                else if (cboTypeHolding.Text.Equals("Double Float") || cboTypeHolding.Text.Equals("Double Float Swap"))
                {
                    try
                    {
                        double dVal = double.Parse(dgHoldings.Rows[idx].Cells[1].Value.ToString());
                        short[] arInt = new short[4];
                        if (cboTypeHolding.Text.Equals("Double Float")) arInt = ConvertDouble2QW(dVal);
                        if (cboTypeHolding.Text.Equals("Double Float Swap")) arInt = ConvertDouble2QWSwap(dVal);
                        ModServer.holdingRegisters[iReg] = arInt[0];
                        ModServer.holdingRegisters[iReg + 1] = arInt[1];
                        ModServer.holdingRegisters[iReg + 2] = arInt[2];
                        ModServer.holdingRegisters[iReg + 3] = arInt[3];
                    }
                    catch (Exception ex)
                    {
                        ex.ToString();
                        double dVal = 0;
                        if (cboTypeHolding.Text.Equals("Double Float")) dVal = CovertQW2Double(ModServer.holdingRegisters[iReg], ModServer.holdingRegisters[iReg + 1], ModServer.holdingRegisters[iReg + 2], ModServer.holdingRegisters[iReg + 3]);
                        if (cboTypeHolding.Text.Equals("Double Float Swap")) dVal = CovertQW2DoubleSwap(ModServer.holdingRegisters[iReg], ModServer.holdingRegisters[iReg + 1], ModServer.holdingRegisters[iReg + 2], ModServer.holdingRegisters[iReg + 3]);
                        dgHoldings.Rows[idx].Cells[1].Value = dVal;
                    }
                }
            }
        }

        private void TxtNewValue_KeyDown(object sender, KeyEventArgs e)
        {
            if(e.KeyCode == Keys.Enter)
            {
                BtnOkChangeValue_Click(null, null);
            }
        }

        private void rdbRtuSlave_CheckedChanged(object sender, EventArgs e)
        {
            if (rdbRtuSlave.Checked)
            {
                btnConnect.Visible = false;
                btnStart.Visible = true;
                dgAnalogs.Columns[1].ReadOnly = false;
                dgHoldings.Columns[1].ReadOnly = false;
                panelTCP.Visible = false;
                panelRTU.Visible = true;
                txtPollInterval.Enabled = false;
            }
        }

        private void rdbRtuMaster_CheckedChanged(object sender, EventArgs e)
        {
            if (rdbRtuMaster.Checked)
            {
                btnConnect.Visible = true;
                btnStart.Visible = false;
                dgAnalogs.Columns[1].ReadOnly = true;
                dgHoldings.Columns[1].ReadOnly = true;
                panelTCP.Visible = false;
                panelRTU.Visible = true;
                txtPollInterval.Enabled = true;
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            string[] ports = SerialPort.GetPortNames();
            if (ports.Length > 0)
            {
                cboRtuPort.Items.Clear();
                foreach (string port in ports)
                {
                    cboRtuPort.Items.Add(port);
                }
                cboRtuPort.SelectedIndex = -1;
            }
        }

        private void btnAddUnit_Click(object sender, EventArgs e)
        {

        }

        private void cboUnitID_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
